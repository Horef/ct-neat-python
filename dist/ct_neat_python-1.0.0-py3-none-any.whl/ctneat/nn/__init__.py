from ctneat.nn.feed_forward import FeedForwardNetwork
from ctneat.nn.recurrent import RecurrentNetwork
